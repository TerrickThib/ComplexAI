# ComplexAI
## How To Open Game 
* Open the Unreal.exe file 
# How to Use 
* You controlle the player with W,A,S,D to move.
# Goal of application 
* The goal of the application is to display the Ai switching to a weapon if the enemy is with a sertain range. I also displays a complex Ai making a decision to patrol, to chase and to equipt weapon and fire.
* The enemy AI will patrol till they spot the player then chase the player, and if the player is in range the Ai will switch to a weapon and fire. 
# How to use in Game 
* You can create a Ai that uses the blue prints and behaviour tree that i created. You could also edit the range at which the Ai switches to its weapon.
# Known Bugs 
No known bugs